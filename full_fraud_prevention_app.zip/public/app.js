
const token = localStorage.getItem('token');
const role = localStorage.getItem('role');
const userName = localStorage.getItem('name');

// จัดการเมนู Navigation
const navLinks = document.getElementById('nav-links');
if (navLinks) {
    if (token) {
        let menu = `
            <li class="nav-item"><a class="nav-link" href="/">ค้นหา</a></li>
            <li class="nav-item"><a class="nav-link" href="/report.html">แจ้งเบาะแส</a></li>
        `;
        if (role === 'admin') {
            menu += `<li class="nav-item"><a class="nav-link text-warning" href="/admin.html">จัดการแอดมิน</a></li>`;
        }
        menu += `<li class="nav-item"><a class="nav-link text-danger" href="#" onclick="logout()">ออกจากระบบ (${userName})</a></li>`;
        navLinks.innerHTML = menu;
    } else {
        navLinks.innerHTML = `
            <li class="nav-item"><a class="nav-link" href="/">ค้นหา</a></li>
            <li class="nav-item"><a class="nav-link" href="/login.html">เข้าสู่ระบบ</a></li>
            <li class="nav-item"><a class="nav-link" href="/register.html">สมัครสมาชิก</a></li>
        `;
    }
}

function logout() {
    localStorage.clear();
    window.location.href = '/';
}

// ฟังก์ชัน Login
async function login() {
    const phone = document.getElementById('phone').value;
    const password = document.getElementById('password').value;
    const res = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone, password })
    });
    const data = await res.json();
    const alertBox = document.getElementById('loginAlert');
    if (res.ok) {
        localStorage.setItem('token', data.token);
        localStorage.setItem('role', data.role);
        localStorage.setItem('name', data.name);
        window.location.href = '/';
    } else {
        alertBox.textContent = data.error;
        alertBox.classList.remove('d-none');
    }
}

// ฟังก์ชัน Register
async function register() {
    const name = document.getElementById('regName').value;
    const phone = document.getElementById('regPhone').value;
    const password = document.getElementById('regPassword').value;
    const res = await fetch('/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, phone, password })
    });
    const data = await res.json();
    const alertBox = document.getElementById('regAlert');
    alertBox.classList.remove('d-none', 'alert-danger', 'alert-success');
    if (res.ok) {
        alertBox.classList.add('alert-success');
        alertBox.textContent = "สมัครสมาชิกสำเร็จ กรุณาเข้าสู่ระบบ";
        setTimeout(() => window.location.href = '/login.html', 1500);
    } else {
        alertBox.classList.add('alert-danger');
        alertBox.textContent = data.error;
    }
}

// ฟังก์ชัน ค้นหา (Search)
async function searchFraud() {
    const q = document.getElementById('searchInput').value;
    const res = await fetch(`/api/reports/search?q=${q}`);
    const data = await res.json();
    const resultBox = document.getElementById('searchResults');
    if (data.length === 0) {
        resultBox.innerHTML = '<div class="alert alert-success">ไม่พบประวัติการโกงจากคำค้นหานี้</div>';
        return;
    }
    let html = '<ul class="list-group">';
    data.forEach(item => {
        html += `<li class="list-group-item list-group-item-danger">
            <strong>ชื่อ:</strong> ${item.suspect_name} <br>
            <strong>บัญชี:</strong> ${item.bank_account} <br>
            <strong>พฤติกรรม:</strong> ${item.details} <br>
            <span class="badge bg-warning text-dark">สถานะ: ${item.status}</span>
        </li>`;
    });
    html += '</ul>';
    resultBox.innerHTML = html;
}

// ฟังก์ชัน แจ้งโกง
async function submitReport() {
    const suspect_name = document.getElementById('suspect_name').value;
    const bank_account = document.getElementById('bank_account').value;
    const damage_amount = document.getElementById('damage_amount').value;
    const details = document.getElementById('details').value;
    
    const res = await fetch('/api/reports', {
        method: 'POST',
        headers: { 
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        },
        body: JSON.stringify({ suspect_name, bank_account, damage_amount, details })
    });
    const data = await res.json();
    const alertBox = document.getElementById('reportAlert');
    alertBox.classList.remove('d-none', 'alert-danger', 'alert-success');
    if (res.ok) {
        alertBox.classList.add('alert-success');
        alertBox.textContent = "บันทึกข้อมูลแจ้งเบาะแสเรียบร้อยแล้ว";
        setTimeout(() => window.location.href = '/', 2000);
    } else {
        alertBox.classList.add('alert-danger');
        alertBox.textContent = data.error || "เกิดข้อผิดพลาด";
    }
}

// โหลดหน้า Admin
if (window.location.pathname === '/admin.html') {
    if (role !== 'admin') {
        alert("คุณไม่มีสิทธิ์เข้าถึงหน้านี้");
        window.location.href = '/';
    } else {
        loadUsers();
    }
}

async function loadUsers() {
    const res = await fetch('/api/admin/users', {
        headers: { 'Authorization': 'Bearer ' + token }
    });
    const users = await res.json();
    const tbody = document.getElementById('userTableBody');
    tbody.innerHTML = '';
    users.forEach(u => {
        tbody.innerHTML += `
            <tr>
                <td>${u.id}</td>
                <td>${u.name}</td>
                <td>${u.phone}</td>
                <td><span class="badge ${u.role === 'admin' ? 'bg-danger' : 'bg-secondary'}">${u.role}</span></td>
                <td>
                    <select class="form-select form-select-sm d-inline w-auto" id="role-${u.id}">
                        <option value="member" ${u.role === 'member' ? 'selected' : ''}>Member</option>
                        <option value="admin" ${u.role === 'admin' ? 'selected' : ''}>Admin</option>
                    </select>
                    <button class="btn btn-sm btn-primary" onclick="updateRole(${u.id})">บันทึก</button>
                </td>
            </tr>
        `;
    });
}

async function updateRole(userId) {
    const newRole = document.getElementById(`role-${userId}`).value;
    const res = await fetch(`/api/admin/users/${userId}/role`, {
        method: 'PATCH',
        headers: { 
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        },
        body: JSON.stringify({ newRole })
    });
    const data = await res.json();
    const alertBox = document.getElementById('adminAlert');
    alertBox.classList.remove('d-none', 'alert-danger', 'alert-success');
    if (res.ok) {
        alertBox.classList.add('alert-success');
        alertBox.textContent = data.message;
        loadUsers(); // รีโหลดตาราง
    } else {
        alertBox.classList.add('alert-danger');
        alertBox.textContent = data.error;
    }
}
